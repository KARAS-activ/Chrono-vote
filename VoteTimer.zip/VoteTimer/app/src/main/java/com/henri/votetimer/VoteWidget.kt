package com.henri.votetimer

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews

class VoteWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, build(c))
    }

    companion object {
        fun build(c: Context): RemoteViews {
            val v = RemoteViews(c.packageName, R.layout.widget)
            val left = VoteTimer.endTime(c) - System.currentTimeMillis()
            if (left > 0) {
                v.setViewVisibility(R.id.chrono, View.VISIBLE)
                v.setViewVisibility(R.id.status, View.GONE)
                v.setChronometerCountDown(R.id.chrono, true)
                v.setChronometer(R.id.chrono, SystemClock.elapsedRealtime() + left, null, true)
            } else {
                v.setViewVisibility(R.id.chrono, View.GONE)
                v.setViewVisibility(R.id.status, View.VISIBLE)
            }
            val open = PendingIntent.getActivity(
                c, 2, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            v.setOnClickPendingIntent(R.id.root, open)
            return v
        }

        fun updateAll(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, VoteWidget::class.java))
            for (id in ids) m.updateAppWidget(id, build(c))
        }
    }
}
