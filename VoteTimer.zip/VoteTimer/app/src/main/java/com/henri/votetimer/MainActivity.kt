package com.henri.votetimer

import android.Manifest
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

class MainActivity : Activity() {

    // Phrases qui apparaissent sur la page APRÈS un vote validé (en minuscules, sans apostrophe).
    // À ajuster si besoin : le bouton « J’ai voté » reste là en secours.
    private val successKeywords = listOf(
        "vote a bien", "pris en compte", "enregistré", "merci pour votre vote", "merci d"
    )

    private lateinit var web: WebView
    private val handler = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() {
            checkVote()
            handler.postDelayed(this, 3000)
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)
        }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
        }
        val btn = Button(this).apply {
            text = "J’ai voté ✓ (lancer les 2 h)"
            setOnClickListener {
                VoteTimer.start(this@MainActivity)
                Toast.makeText(context, "Chrono de 2 h lancé", Toast.LENGTH_SHORT).show()
            }
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(btn)
            addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(root)
        web.loadUrl(VoteTimer.URL)
    }

    private fun checkVote() {
        if (VoteTimer.isRunning(this)) return
        val keys = successKeywords.joinToString(",") { "\"$it\"" }
        val js = "(function(){var t=document.body.innerText.toLowerCase();" +
            "return [$keys].some(function(k){return t.indexOf(k)>-1})})()"
        web.evaluateJavascript(js) { r ->
            if (r == "true" && !VoteTimer.isRunning(this)) {
                VoteTimer.start(this)
                Toast.makeText(this, "Vote détecté : chrono de 2 h lancé", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onResume() { super.onResume(); handler.post(poll) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(poll) }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
