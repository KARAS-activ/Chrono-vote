package com.henri.votetimer

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

object VoteTimer {
    const val URL = "https://top-serveurs.net/gta/vote/legacyworld"
    const val DURATION = 2 * 60 * 60 * 1000L

    private fun prefs(c: Context) = c.getSharedPreferences("vote", Context.MODE_PRIVATE)

    fun endTime(c: Context): Long = prefs(c).getLong("end", 0L)
    fun isRunning(c: Context) = endTime(c) > System.currentTimeMillis()

    private fun alarmIntent(c: Context) = PendingIntent.getBroadcast(
        c, 0, Intent(c, AlarmReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun schedule(c: Context, end: Long) {
        val am = c.getSystemService(AlarmManager::class.java)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, alarmIntent(c))
    }

    fun start(c: Context) {
        val end = System.currentTimeMillis() + DURATION
        prefs(c).edit().putLong("end", end).apply()
        schedule(c, end)
        VoteWidget.updateAll(c)
    }

    fun reset(c: Context) {
        prefs(c).edit().putLong("end", 0L).apply()
        c.getSystemService(AlarmManager::class.java).cancel(alarmIntent(c))
        VoteWidget.updateAll(c)
    }
}
