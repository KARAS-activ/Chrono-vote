package com.henri.votetimer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) {
            val end = VoteTimer.endTime(c)
            if (end > System.currentTimeMillis()) VoteTimer.schedule(c, end)
            VoteWidget.updateAll(c)
            return
        }
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("vote", "Rappel de vote", NotificationManager.IMPORTANCE_HIGH)
        )
        val open = PendingIntent.getActivity(
            c, 1, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(c, "vote")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("C’est l’heure de voter !")
            .setContentText("LEGACY WORLD : les 2 h sont écoulées.")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(1, n)
        VoteWidget.updateAll(c)
    }
}
